package com.allaboutkids.controllers;

import com.allaboutkids.entities.Payment;
import com.allaboutkids.entities.Prediction;
import com.allaboutkids.entities.Student;
import com.allaboutkids.services.PaymentService;
import com.allaboutkids.services.PredictionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/prediction")
public class PredictionController {

    @Autowired
    private PredictionService predictionService;

    @GetMapping("")
    public List<Prediction> getAllPredictions(){
        return predictionService.getAllPredictions();
    }

    @PostMapping("")
    public ResponseEntity<HttpStatus> generatePrediction(@RequestBody Prediction prediction) {
        return predictionService.generatePrediction(prediction);
    }
}
