package com.allaboutkids.services;

import com.allaboutkids.entities.Payment;
import com.allaboutkids.entities.Prediction;
import com.allaboutkids.repositories.PaymentRepository;
import com.allaboutkids.repositories.PredictionRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

@Service
public class PredictionService {

    @Autowired
    private PredictionRepository predictionRepository;

    public List<Prediction> getAllPredictions() {
        List<Prediction> allPredictions = predictionRepository.findAll();
//        List<Payment> sortedPayments = allPayments.stream()
//                .sorted(Comparator.comparing(Payment::getMonth))
//                .collect(Collectors.toList());
        return allPredictions;
    }

    public ResponseEntity<HttpStatus> generatePrediction(Prediction prediction) {

        try {
            ObjectMapper jsonMapper = new ObjectMapper();
            String json = jsonMapper.writeValueAsString(prediction);
            HttpRequest request = HttpRequest.newBuilder()
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .uri(new URI("/post"))
                    .header("Authorization", "")
                    .header("Content-type", "application/json")
                    .header("Accept", "application/json")
                    .build();

            HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        } catch (URISyntaxException | IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
