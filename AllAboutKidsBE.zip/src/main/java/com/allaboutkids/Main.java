package com.allaboutkids;

import com.allaboutkids.entities.Payment;
import com.allaboutkids.entities.Student;
import com.allaboutkids.services.PaymentService;
import com.allaboutkids.services.StudentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

@SpringBootApplication
public class Main implements CommandLineRunner {

    public static void main(String[] args) {

        SpringApplication.run(Main.class, args);
    }

    @Autowired
    StudentService studentService;
    @Autowired
    PaymentService paymentService;

    @Override
    public void run(String... args) {

        try {
            List<Student> students = studentService.getAllStudents();
            ObjectMapper jsonMapper = new ObjectMapper();
            String json = jsonMapper.writeValueAsString(students);
            HttpRequest request = HttpRequest.newBuilder()
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .uri(new URI("/cpi/students"))
                    .header("Authorization", "")
                    .header("Content-type", "application/json")
                    .header("Accept", "application/json")
                    .build();

            HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        } catch (URISyntaxException | IOException | InterruptedException e) {
            e.printStackTrace();
        }

        try {
            List<Payment> payments = paymentService.getAllPayments();
            ObjectMapper jsonMapper = new ObjectMapper();
            String json = jsonMapper.writeValueAsString(payments);
            HttpRequest request = HttpRequest.newBuilder()
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .uri(new URI("/cpi/payments"))
                    .header("Authorization", "")
                    .header("Content-type", "application/json")
                    .header("Accept", "application/json")
                    .build();

            HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        } catch (URISyntaxException | IOException | InterruptedException e) {
            e.printStackTrace();
        }


    }
}